import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
    <h1> Movie: <u>Hari Hara Veera Mallu</u></h1>
    <div className="containerDiv">
    <div className="itemsDiv">
    <img width="370px" height="320px" 
    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbynOHfSoIAqrM8-Vi-476zPE1N_jlIIpbzQ&s"></img>
    <h3>Teaser</h3>
    </div>
    <div className="itemsDiv" >
    <iframe width="560" height="315" src="https://www.youtube.com/embed/4TriF7BfHyI?si=tbHZxe5IC1v1yhjB" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    <h3>Trailer</h3>
    </div>
  </div>
  </div>
  );
}

export default App;
